from django.shortcuts import render, get_object_or_404, redirect
from django.views.generic import CreateView, ListView, UpdateView, DeleteView
from django.urls import reverse_lazy
from . models import *
from django.http import HttpResponse
from . forms import *
from django.contrib.auth.decorators import login_required

# Create your views here.
def homepage(req):
    return render(req,'home.html')
def StudentCreateView(CreateView):
    model=Student
    fields='__all__'
    success_url=reverse_lazy('home')
    template_name='create.html'

#To Create a form
class create(CreateView):
    model = Student
    fields = '__all__'
    success_url = reverse_lazy('home')
    template_name = 'create.html'

#Read - will display the results created above

class readpage(ListView):
    model = Student
    fields='__all__'
    context_object_name = 'data'
    template_name = 'read.html'

# To Update
class updatepage(UpdateView):
    model = Student
    fields = '__all__'
    template_name = 'update.html'
    success_url = reverse_lazy('read')
    def get_object(self, queryset=None):
        return get_object_or_404(Student,pk=self.kwargs['id'])

class deletepage(DeleteView):
    model = Student
    fields = '__all__'
    template_name = 'delete.html'
    success_url = reverse_lazy('read')
    def get_object(self, queryset=None):
        return get_object_or_404(Student, pk=self.kwargs['id'])

def signuppage(req):
    frm=Signupform(req.POST or None)
    if frm.is_valid():
        frm.save()
        return HttpResponse('User Created')
    return render(req,'signup.html',{'myform':frm})

def staffpage(req):
    return render(req,'staff.html')

def imagepage(req):
    frm=imageform(req.POST, req.FILES)
    if frm.is_valid():
        frm.save()
        return HttpResponse ('image uploaded')
    return render(req, 'image.html', {'myform':frm})