from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator

# Create your models here.
class Student(models.Model):
    name=models.CharField(max_length=50)
    age=models.IntegerField()
    mobile=models.BigIntegerField()
    email=models.EmailField()
    datetime=models.DateTimeField(auto_now=True)
    rollno=models.IntegerField(validators=[MaxValueValidator(5),MaxValueValidator(100)])

class Getimage(models.Model):
    name = models.CharField(max_length=25)
    img = models.ImageField(upload_to='image/')